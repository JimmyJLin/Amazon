The following command deletes an SNS topic named ``my-topic``::

  aws sns delete-topic --topic-arn "arn:aws:sns:us-west-2:0123456789012:my-topic"