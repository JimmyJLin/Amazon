Delete a Cluster subnet Group
-----------------------------

This example deletes a cluster subnet group.

Command::

   aws redshift delete-cluster-subnet-group --cluster-subnet-group-name mysubnetgroup

Result::

    {
       "ResponseMetadata": {
          "RequestId": "253fbffd-6993-11e2-bc3a-47431073908a"
       }
    }


